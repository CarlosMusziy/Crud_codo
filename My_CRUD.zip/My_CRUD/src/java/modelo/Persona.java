
package modelo;


public class Persona {
    
    int id;
    String dni;
    String nom;
    Float nota_1;
    Float nota_2;
    Float promedio;

    public Persona() {
    }

    public Persona(int id, String dni, String nom, Float nota_1, Float nota_2, Float promedio) {
        this.id = id;
        this.dni = dni;
        this.nom = nom;
        this.nota_1 = nota_1;
        this.nota_2 = nota_2;
        this.promedio = promedio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Float getNota_1() {
        return nota_1;
    }

    public void setNota_1(Float nota_1) {
        this.nota_1 = nota_1;
    }

    public Float getNota_2() {
        return nota_2;
    }

    public void setNota_2(Float nota_2) {
        this.nota_2 = nota_2;
    }

    public Float getPromedio() {
        return promedio;
    }

    public void setPromedio(Float promedio) {
        this.promedio = promedio;
    }

    
        
    }
    
    

    

    


